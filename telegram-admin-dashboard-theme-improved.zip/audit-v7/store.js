'use strict';
const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, 'data');
const DATA_FILE = path.join(DATA_DIR, 'store.json');

const FALLBACK = {
  settings: { periodStart: '2026-09-14', periodEnd: '2026-09-20', periodDays: 7 },
  roles: [
    { name: 'Управляющая', banNorm: 40, acceptNorm: 80 },
    { name: 'Совладелец', banNorm: 40, acceptNorm: 80 },
    { name: 'Разработчик', banNorm: 0, acceptNorm: 0 },
    { name: 'Старший администратор', banNorm: 30, acceptNorm: 60 },
    { name: 'Младший администратор', banNorm: 20, acceptNorm: 40 }
  ],
  admins: [],
  bans: [],
  requests: [],
  activity: [],
  telegram: { lastUpdateId: 0, processedUpdateIds: [] }
};

function ensureStore() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(DATA_FILE)) {
    fs.writeFileSync(DATA_FILE, JSON.stringify(FALLBACK, null, 2), { mode: 0o600 });
  }
  try { fs.chmodSync(DATA_FILE, 0o600); } catch {}
}

function clone(v) {
  return JSON.parse(JSON.stringify(v));
}

function clampInt(v, max = 100000) {
  const n = Number(v);
  if (!Number.isFinite(n)) return 0;
  return Math.max(0, Math.min(max, Math.floor(n)));
}

function normalize(input) {
  const s = (input && typeof input === 'object') ? input : {};
  const out = {
    settings: { ...FALLBACK.settings, ...(s.settings || {}) },
    roles: Array.isArray(s.roles) ? s.roles : clone(FALLBACK.roles),
    admins: [],
    bans: [],
    requests: [],
    activity: Array.isArray(s.activity) ? s.activity : [],
    telegram: { ...FALLBACK.telegram, ...(s.telegram || {}) }
  };

  out.admins = (Array.isArray(s.admins) ? s.admins : FALLBACK.admins).map((a, i) => ({
    ...a,
    id: Number(a?.id) || i + 1,
    name: String(a?.name || '').trim().slice(0, 80),
    uid: String(a?.uid || '').trim().slice(0, 32),
    telegram: String(a?.telegram || '—').trim().slice(0, 64) || '—',
    telegramId: String(a?.telegramId ?? a?.telegram_id ?? '').trim().slice(0, 32),
    role: String(a?.role || '').trim(),
    bans: clampInt(a?.bans),
    accepted: clampInt(a?.accepted)
  }));

  const adminByName = new Map(out.admins.map(a => [a.name, a]));
  out.bans = (Array.isArray(s.bans) ? s.bans : []).map((b, i) => {
    const adminId = b?.adminId ? Number(b.adminId) : (adminByName.get(String(b?.admin || ''))?.id || null);
    const durationMap = { 'навсегда': 'Навсегда', '24 часа': '1 день', '30 дней': '30 дней', '7 дней': '7 дней', '1 день': '1 день' };
    const reason = ['Спам', 'Реклама', 'Оскорбления', 'Читы', 'Другое', 'Telegram: бан'].includes(b?.reason) ? b.reason : 'Другое';
    return {
      ...b,
      id: Number(b?.id) || i + 1,
      time: String(b?.time || ''),
      timeInput: String(b?.timeInput || ''),
      user: String(b?.user || '').slice(0, 80),
      uid: String(b?.uid || '').slice(0, 32),
      reason,
      duration: durationMap[String(b?.duration || '')] || String(b?.duration || 'Навсегда'),
      admin: String(b?.admin || 'Ирис').slice(0, 80),
      adminId,
      telegramUserId: String(b?.telegramUserId || ''),
      chatId: String(b?.chatId || '')
    };
  });

  const byId = new Map(out.admins.map(a => [a.id, a]));
  out.requests = (Array.isArray(s.requests) ? s.requests : []).map((r, i) => {
    const status = ['pending', 'accepted', 'rejected'].includes(r?.status) ? r.status : 'pending';
    const adminId = r?.adminId ? Number(r.adminId) : (r?.acceptedBy ? adminByName.get(String(r.acceptedBy))?.id || null : null);
    return {
      ...r,
      id: Number(r?.id) || i + 1,
      user: String(r?.user || '').slice(0, 80),
      uid: String(r?.uid || '').slice(0, 32),
      status,
      statusLabel: { pending: 'На рассмотрении', accepted: 'Принята', rejected: 'Отклонена' }[status],
      acceptedBy: status === 'accepted' ? String(r?.acceptedBy || byId.get(adminId)?.name || '') : '',
      time: String(r?.time || ''),
      adminId: adminId || null,
      telegramUserId: String(r?.telegramUserId || ''),
      chatId: String(r?.chatId || '')
    };
  });

  out.telegram.lastUpdateId = Math.max(0, Number(out.telegram.lastUpdateId) || 0);
  out.telegram.processedUpdateIds = Array.isArray(out.telegram.processedUpdateIds)
    ? out.telegram.processedUpdateIds.map(Number).filter(Number.isFinite).slice(-1000)
    : [];
  out.activity = out.activity.slice(0, 500);
  return out;
}

function readStore() {
  ensureStore();
  try {
    return normalize(JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')));
  } catch {
    return normalize(FALLBACK);
  }
}

const store = readStore();

function saveStore() {
  const tmp = DATA_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(store, null, 2), { mode: 0o600 });
  try { fs.chmodSync(tmp, 0o600); } catch {}
  fs.renameSync(tmp, DATA_FILE);
  try { fs.chmodSync(DATA_FILE, 0o600); } catch {}
}

module.exports = { DATA_FILE, store, readStore, saveStore, ensureStore };
