'use strict';
const fs = require('fs');
const path = require('path');
const https = require('https');
const dns = require('dns');

// Prefer IPv4 first. Some Windows networks have broken/partial IPv6 routes.
try { dns.setDefaultResultOrder('ipv4first'); } catch {}
const { store, saveStore } = require('./store');

function loadEnv(file){
  if(!fs.existsSync(file))return;
  for(const line of fs.readFileSync(file,'utf8').split(/\r?\n/)){
    const m=line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/);
    if(m && !process.env[m[1]]) process.env[m[1]]=m[2].replace(/^['"]|['"]$/g,'');
  }
}
loadEnv(path.join(__dirname,'.env'));

const TOKEN=process.env.TELEGRAM_BOT_TOKEN||'';
const GROUP_ID=process.env.TELEGRAM_GROUP_ID||'';
const WEBHOOK_SECRET=process.env.TELEGRAM_WEBHOOK_SECRET||'';
const SITE_URL=(process.env.SITE_URL||'').replace(/\/$/,'');
const BOT_MODE=(process.env.BOT_MODE||'').toLowerCase() || (SITE_URL?'webhook':'polling');
const API_TIMEOUT=35000;
let running=false;
let botUsername='';
const status={configured:Boolean(TOKEN),connected:false,mode:BOT_MODE,username:'',error:null,startedAt:null};

if(!TOKEN) throw new Error('TELEGRAM_BOT_TOKEN is required. Запиши токен в .env и запусти START_WINDOWS.bat ещё раз.');
if(!['polling','webhook'].includes(BOT_MODE)) throw new Error('BOT_MODE must be polling or webhook');
if(BOT_MODE==='webhook' && !SITE_URL) throw new Error('SITE_URL is required for BOT_MODE=webhook');
if(BOT_MODE==='webhook' && !/^https:\/\//i.test(SITE_URL)) throw new Error('BOT_MODE=webhook requires an HTTPS SITE_URL');
if(BOT_MODE==='webhook' && !WEBHOOK_SECRET) throw new Error('TELEGRAM_WEBHOOK_SECRET is required for webhook');
if(WEBHOOK_SECRET && !/^[A-Za-z0-9_-]{1,256}$/.test(WEBHOOK_SECRET)) throw new Error('TELEGRAM_WEBHOOK_SECRET must contain only A-Z, a-z, 0-9, _ or - (1-256 chars)');

function api(method, body={}, timeoutMs=API_TIMEOUT){
  return new Promise((resolve,reject)=>{
    const payload=Buffer.from(JSON.stringify(body),'utf8');
    const req=https.request({
      protocol:'https:',
      hostname:'api.telegram.org',
      family:4,
      port:443,
      method:'POST',
      path:`/bot${TOKEN}/${method}`,
      headers:{'Content-Type':'application/json','Content-Length':payload.length,'Connection':'close'},
      timeout:timeoutMs,
      servername:'api.telegram.org'
    },res=>{
      let raw='';
      res.setEncoding('utf8');
      res.on('data',chunk=>{raw+=chunk; if(raw.length>2*1024*1024) req.destroy(new Error('Telegram response too large'));});
      res.on('end',()=>{
        let j={};
        try{j=JSON.parse(raw)}catch{}
        if(res.statusCode<200||res.statusCode>=300||!j.ok){
          const e=new Error(j.description||`Telegram API HTTP ${res.statusCode}`);
          e.code=j.error_code?`TELEGRAM_${j.error_code}`:undefined;
          e.statusCode=res.statusCode;
          reject(e); return;
        }
        resolve(j.result);
      });
    });
    req.on('timeout',()=>req.destroy(Object.assign(new Error(`connection timeout after ${timeoutMs}ms`),{code:'ETIMEDOUT'})));
    req.on('error',err=>{
      const e=new Error(err.message||String(err));
      e.code=err.code; e.errno=err.errno; e.syscall=err.syscall; e.address=err.address; e.port=err.port; e.cause=err.cause;
      reject(e);
    });
    req.write(payload);
    req.end();
  });
}

function formatNetworkError(e){
  const parts=[e?.code,e?.syscall,e?.address,e?.port].filter(Boolean);
  return [e?.message||String(e),parts.length?`[${parts.join(' ')}]`:''].filter(Boolean).join(' ');
}
function uid(u){return String(u?.id||'');}
function username(u){return u?.username ? `@${u.username}` : '';}
function display(u){return u?.username?`@${u.username}`:[u?.first_name,u?.last_name].filter(Boolean).join(' ')||uid(u);}
function normUsername(v){return String(v||'').trim().replace(/^@/,'').toLowerCase();}
function adminByTelegram(s,u){
  const id=uid(u), uname=normUsername(username(u));
  const a=s.admins.find(x=>String(x.telegramId||x.telegram_id||'')===id || normUsername(x.telegram)===uname);
  if(a && id && String(a.telegramId||'')!==id){ a.telegramId=id; }
  return a;
}
function now(){const d=new Date();return d.toISOString().slice(0,16).replace('T',' ');}
function activity(s,action,target,detail){
  s.activity=s.activity||[];
  s.activity.unshift({id:Date.now()+Math.floor(Math.random()*999),time:new Date().toLocaleString('ru-RU',{hour12:false}),action,actor:'Telegram Bot',target:String(target||''),detail:String(detail||'')});
  s.activity=s.activity.slice(0,500);
}
function isTargetChat(chatId){return !GROUP_ID || String(chatId)===String(GROUP_ID);}
function markProcessed(s, updateId){
  if(!Number.isFinite(Number(updateId))) return false;
  const id=Number(updateId);
  s.telegram=s.telegram||{lastUpdateId:0,processedUpdateIds:[]};
  s.telegram.processedUpdateIds=s.telegram.processedUpdateIds||[];
  if(s.telegram.processedUpdateIds.includes(id)) return false;
  s.telegram.processedUpdateIds.push(id);
  if(s.telegram.processedUpdateIds.length>1000) s.telegram.processedUpdateIds=s.telegram.processedUpdateIds.slice(-1000);
  s.telegram.lastUpdateId=Math.max(Number(s.telegram.lastUpdateId)||0,id);
  return true;
}

async function onJoinRequest(u,s){
  if(!isTargetChat(u.chat?.id)) return false;
  s.requests=s.requests||[];
  const user=u.from || u.user;
  const userId=uid(user);
  const existing=s.requests.find(r=>String(r.telegramUserId||r.uid)===userId && r.status==='pending' && String(r.chatId||'')===String(u.chat.id));
  if(existing) return false;
  const id=Math.max(0,...s.requests.map(r=>Number(r.id)||0))+1;
  s.requests.unshift({id,user:display(user),uid:userId,telegramUserId:userId,status:'pending',statusLabel:'На рассмотрении',time:new Date((u.date||Date.now()/1000)*1000).toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit'}),chatId:String(u.chat.id)});
  activity(s,'request.telegram','Вступление',`${display(user)} подал заявку`);
  return true;
}

function formatUntil(untilDate){
  if(!untilDate) return {duration:'Навсегда',untilDate:null};
  const d=new Date(Number(untilDate)*1000);
  if(!Number.isFinite(d.getTime())) return {duration:'Не указано',untilDate:null};
  return {duration:'Не указано',untilDate:Math.floor(Number(untilDate))};
}

async function onChatMember(update,s){
  const cm=update.chat_member;
  if(!cm || !isTargetChat(cm.chat?.id)) return false;
  const old=cm.old_chat_member?.status,newStatus=cm.new_chat_member?.status;
  if(old===newStatus) return false;
  const user=cm.new_chat_member?.user;
  const actorUser=cm.from;
  const admin=adminByTelegram(s,actorUser);
  let changed=false;

  if(newStatus==='kicked' || (newStatus==='restricted' && cm.new_chat_member?.is_member===false)){
    if(!admin) return false;
    const id=Math.max(0,...s.bans.map(b=>Number(b.id)||0))+1;
    const banDuration=formatUntil(cm.new_chat_member?.until_date);s.bans.unshift({id,time:now(),timeInput:new Date((cm.date||Date.now()/1000)*1000).toISOString().slice(0,16),user:display(user),reason:'Telegram: бан',admin:admin.name,adminId:admin.id,duration:banDuration.duration,untilDate:banDuration.untilDate,uid:uid(user),telegramUserId:uid(user),chatId:String(cm.chat.id),source:'telegram'});
    if(admin.role!=='Разработчик') admin.bans=Number(admin.bans||0)+1;
    activity(s,'ban.telegram',display(user),`Заблокировал ${admin.name}`);
    changed=true;
  }

  if((newStatus==='member'||newStatus==='administrator') && (old==='left'||old==='kicked')){
    const req=s.requests.find(r=>String(r.telegramUserId||r.uid)===uid(user)&&r.status==='pending'&&String(r.chatId||'')===String(cm.chat.id));
    if(req){
      req.status='accepted';
      req.statusLabel='Принята';
      req.acceptedBy=admin?.name||display(actorUser);
      req.adminId=admin?.id||null;
      if(admin && admin.role!=='Разработчик') admin.accepted=Number(admin.accepted||0)+1;
      activity(s,'request.telegram.accept',display(user),`Принял ${req.acceptedBy}`);
      changed=true;
    }
  }
  return changed;
}

async function onMessage(m,s){
  if(!m?.chat)return false;
  if(GROUP_ID && m.chat.type!=='private' && String(m.chat.id)!==String(GROUP_ID)) return false;
  const text=(m.text||'').trim();
  if(!text.startsWith('/')) return false;
  const [cmdRaw]=text.split(/\s+/);
  const cmd=cmdRaw.split('@')[0].toLowerCase();
  if(cmd==='/start'||cmd==='/help'){await api('sendMessage',{chat_id:m.chat.id,text:`<b>Норма конуры базаров</b>\n\n/norma — показать свою норму\n/site — открыть панель\n/id — показать Telegram ID\n/groupid — показать ID группы\n/help — помощь`,parse_mode:'HTML',disable_web_page_preview:true});return false;}
  if(cmd==='/id'){await api('sendMessage',{chat_id:m.chat.id,text:`Ваш Telegram ID: <code>${uid(m.from)}</code>`,parse_mode:'HTML'});return false;}
  if(cmd==='/groupid'){await api('sendMessage',{chat_id:m.chat.id,text:`ID этого чата: <code>${m.chat.id}</code>`,parse_mode:'HTML'});return false;}
  if(cmd==='/site'){await api('sendMessage',{chat_id:m.chat.id,text:SITE_URL?`Панель: ${SITE_URL}`:'SITE_URL не настроен',disable_web_page_preview:true});return false;}
  if(cmd==='/norma'){
    const a=adminByTelegram(s,m.from);
    if(!a){await api('sendMessage',{chat_id:m.chat.id,text:'Ваш Telegram не привязан к администратору сайта.'});return false;}
    if(!['Управляющая','Совладелец','Разработчик'].includes(a.role)){await api('sendMessage',{chat_id:m.chat.id,text:'Раздел нормы доступен только управляющей, совладельцу и разработчику.'});return false;}
    const r=s.roles.find(x=>x.name===a.role)||{banNorm:0,acceptNorm:0};
    const ban=r.banNorm?Math.min(100,Math.round(a.bans/r.banNorm*100)):100;
    const acc=r.acceptNorm?Math.min(100,Math.round(a.accepted/r.acceptNorm*100)):100;
    await api('sendMessage',{chat_id:m.chat.id,text:`<b>${a.name}</b>\nРоль: ${a.role}\n\nБаны: ${a.bans}/${r.banNorm||'—'} (${ban}%)\nПринято: ${a.accepted}/${r.acceptNorm||'—'} (${acc}%)`,parse_mode:'HTML'});
    if(a.telegramId===uid(m.from)) saveStore();
  }
  return false;
}

async function handle(update){
  const s=store;
  const updateId=Number(update?.update_id);
  if(Number.isFinite(updateId) && !markProcessed(s,updateId)) return false;
  let changed=false;
  try{
    if(update.message) changed=await onMessage(update.message,s) || changed;
    if(update.chat_join_request) changed=await onJoinRequest(update.chat_join_request,s) || changed;
    if(update.chat_member) changed=await onChatMember(update,s) || changed;
    if(Number.isFinite(updateId)) changed=true;
    if(changed) saveStore();
    return true;
  }catch(e){
    if(Number.isFinite(updateId)){
      s.telegram.processedUpdateIds=s.telegram.processedUpdateIds.filter(x=>Number(x)!==updateId);
    }
    throw e;
  }
}

async function configure(){
  status.error=null;
  console.log('Telegram: подключение к Bot API (IPv4)...');
  const me=await api('getMe');
  botUsername=me.username||'';
  status.connected=true;
  status.username=botUsername;
  status.startedAt=new Date().toISOString();
  console.log(`Telegram bot @${botUsername} connected (${BOT_MODE})`);
  try{await api('setMyCommands',{commands:[
    {command:'norma',description:'Показать свою норму'},
    {command:'site',description:'Открыть панель'},
    {command:'id',description:'Показать Telegram ID'},
    {command:'groupid',description:'Показать ID группы'},
    {command:'help',description:'Помощь'}
  ]});}catch(e){console.warn('Telegram: не удалось обновить список команд:',formatNetworkError(e));}
  if(BOT_MODE==='webhook'){
    await api('setWebhook',{url:`${SITE_URL}/telegram/webhook`,allowed_updates:['message','chat_join_request','chat_member'],secret_token:WEBHOOK_SECRET});
    console.log('Telegram webhook configured');
  }else{
    await api('deleteWebhook',{drop_pending_updates:false});
    console.log('Telegram polling enabled');
  }
}

async function poll(){
  if(running)return;
  running=true;
  let offset=Math.max(0,Number(store.telegram?.lastUpdateId||0)+1);
  while(running){
    try{
      const updates=await api('getUpdates',{offset,timeout:25,allowed_updates:['message','chat_join_request','chat_member']},35000);
      for(const update of updates){
        await handle(update);
        if(Number.isFinite(Number(update.update_id))) offset=Number(update.update_id)+1;
      }
    }catch(e){
      status.error=e.message;
      status.connected=false;
      if(running) console.error('Telegram polling:',formatNetworkError(e));
      await new Promise(r=>setTimeout(r,1500));
    }
  }
}

async function start(){
  status.error=null;
  if(BOT_MODE==='polling'){
    while(true){
      try{await configure();await poll();return;}
      catch(e){status.error=e.message;status.connected=false;console.error('Telegram startup:',formatNetworkError(e));await new Promise(r=>setTimeout(r,5000));}
    }
  }
  await configure();
}

function stop(){running=false;}

if(require.main===module){start().catch(e=>{console.error(e);process.exit(1);});process.on('SIGINT',()=>{stop();process.exit(0)});process.on('SIGTERM',()=>{stop();process.exit(0)});}
module.exports={handle,start,stop,configure,getStatus:()=>({...status}),_test:{onJoinRequest,onChatMember,markProcessed,adminByTelegram}};
