#!/usr/bin/env node
'use strict';
const fs=require('fs');
const path=require('path');
const https=require('https');
const dns=require('dns');
try{dns.setDefaultResultOrder('ipv4first')}catch{}

function loadEnv(file){
  if(!fs.existsSync(file)) return;
  for(const line of fs.readFileSync(file,'utf8').split(/\r?\n/)){
    const m=line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/);
    if(m && !process.env[m[1]]) process.env[m[1]]=m[2].replace(/^['"]|['"]$/g,'');
  }
}
loadEnv(path.join(__dirname,'.env'));

const token=process.env.TELEGRAM_BOT_TOKEN||'';
const mode=(process.env.BOT_MODE||'polling').toLowerCase();
const groupId=process.env.TELEGRAM_GROUP_ID||'';
const siteUrl=(process.env.SITE_URL||'').replace(/\/$/,'');
console.log(`BOT_MODE=${mode}`);

if(!['polling','webhook'].includes(mode)){
  console.error('[ОШИБКА] BOT_MODE должен быть polling или webhook.');
  process.exit(1);
}
if(!token){
  console.error('[ОШИБКА] TELEGRAM_BOT_TOKEN пустой.');
  console.error('Открой .env и запиши туда новый токен BotFather.');
  process.exit(1);
}
if(!/^\d+:[A-Za-z0-9_-]+$/.test(token)){
  console.error('[ОШИБКА] TELEGRAM_BOT_TOKEN выглядит неправильно.');
  console.error('Вставь токен целиком одной строкой, без кавычек и пробелов.');
  process.exit(1);
}
if(mode==='webhook' && !/^https:\/\//i.test(siteUrl)){
  console.error('[ОШИБКА] Для webhook нужен HTTPS SITE_URL.');
  process.exit(1);
}
if(mode==='webhook' && !process.env.TELEGRAM_WEBHOOK_SECRET){
  console.error('[ОШИБКА] Для webhook нужен TELEGRAM_WEBHOOK_SECRET.');
  process.exit(1);
}

function request(method,body={},timeout=10000){
  return new Promise((resolve,reject)=>{
    const payload=Buffer.from(JSON.stringify(body),'utf8');
    const req=https.request({hostname:'api.telegram.org',family:4,port:443,path:`/bot${token}/${method}`,method:'POST',headers:{'Content-Type':'application/json','Content-Length':payload.length,'Connection':'close'},timeout,servername:'api.telegram.org'},res=>{
      let raw='';res.setEncoding('utf8');
      res.on('data',c=>{raw+=c;if(raw.length>1024*1024)req.destroy(Object.assign(Error('Telegram response too large'),{code:'ERESPONSESIZE'}))});
      res.on('end',()=>{let j={};try{j=JSON.parse(raw)}catch{reject(Object.assign(Error('Invalid JSON response'),{code:'EBADJSON'}));return}resolve({statusCode:res.statusCode||0,data:j})});
    });
    req.on('timeout',()=>req.destroy(Object.assign(Error(`timeout after ${timeout}ms`),{code:'ETIMEDOUT'})));
    req.on('error',reject);req.write(payload);req.end();
  });
}
function netText(e){return [e?.code,e?.syscall,e?.address,e?.port].filter(Boolean).join(' ')}
function fail(label,e){console.error(`[ОШИБКА ${label}] ${e.message||e}${netText(e)?` [${netText(e)}]`:''}`);process.exitCode=1}

console.log('[1/5] Проверяю DNS api.telegram.org...');
dns.lookup('api.telegram.org',{family:4},(dnsErr,address)=>{
  if(dnsErr){fail('DNS',dnsErr);return;}
  console.log(`[OK] IPv4: ${address}`);
  console.log('[2/5] Проверяю HTTPS-соединение...');
  const req=https.request({hostname:'api.telegram.org',family:4,port:443,path:'/',method:'GET',headers:{Connection:'close'},timeout:10000,servername:'api.telegram.org'},res=>{
    res.resume();
    res.on('end',async()=>{
      console.log(`[OK] HTTPS соединение установлено (HTTP ${res.statusCode}).`);
      try{
        console.log('[3/5] Проверяю токен через getMe...');
        const meRes=await request('getMe');
        if(!meRes.data?.ok){throw Error(meRes.data?.description||`HTTP ${meRes.statusCode}`)}
        const me=meRes.data.result||{};
        console.log(`[OK] Telegram API отвечает. Бот: @${me.username||me.first_name||'unknown'} (ID ${me.id})`);

        console.log('[4/5] Проверяю состояние webhook...');
        const wh=await request('getWebhookInfo');
        if(!wh.data?.ok) throw Error(wh.data?.description||`HTTP ${wh.statusCode}`);
        const info=wh.data.result||{};
        if(mode==='polling'){
          if(info.url) {console.error(`[ПРЕДУПРЕЖДЕНИЕ] У бота уже установлен webhook: ${info.url}. При запуске polling проект удалит его.`);} else console.log('[OK] Webhook не установлен, polling возможен.');
        }else{
          const expected=`${siteUrl}/telegram/webhook`;
          console.log(info.url===expected?`[OK] Webhook уже указывает на ${expected}.`:`[ПРЕДУПРЕЖДЕНИЕ] Текущий webhook: ${info.url||'(не установлен)'}; ожидается: ${expected}`);
        }

        console.log('[5/5] Проверяю группу и права бота...');
        if(!groupId){
          console.log('[ПРОПУСК] TELEGRAM_GROUP_ID пока пустой. После /groupid впиши ID группы в .env и повтори diagnose.');
          return;
        }
        const chat=await request('getChat',{chat_id:groupId});
        if(!chat.data?.ok){throw Error(`getChat: ${chat.data?.description||`HTTP ${chat.statusCode}`}`)}
        const c=chat.data.result||{};
        console.log(`[OK] Группа: ${c.title||'(без названия)'} | type=${c.type} | id=${c.id}`);
        const member=await request('getChatMember',{chat_id:groupId,user_id:me.id});
        if(!member.data?.ok){throw Error(`getChatMember: ${member.data?.description||`HTTP ${member.statusCode}`}`)}
        const cm=member.data.result||{};
        console.log(`[OK] Статус бота в группе: ${cm.status}`);
        if(cm.status!=='administrator'){
          console.error('[ОШИБКА] Бот не является администратором этой группы. Для chat_member Telegram требует администратора.');
          process.exitCode=1;
          return;
        }
        console.log(`[INFO] can_invite_users=${Boolean(cm.can_invite_users)} | can_restrict_members=${Boolean(cm.can_restrict_members)}`);
        if(!cm.can_invite_users) console.error('[ПРЕДУПРЕЖДЕНИЕ] Без can_invite_users заявки на вступление (chat_join_request) работать не будут.');
      }catch(e){fail('Telegram',e)}
    });
  });
  req.on('timeout',()=>req.destroy(Object.assign(Error('HTTPS timeout after 10000ms'),{code:'ETIMEDOUT'})));
  req.on('error',e=>fail('HTTPS',e));
  req.end();
});
