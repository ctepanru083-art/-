@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul

echo ===============================================
echo   Норма конуры базаров — запуск на Windows
echo ===============================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo [ОШИБКА] Node.js не найден.
  echo Установи Node.js LTS с https://nodejs.org/
  pause
  exit /b 1
)

if not exist ".env" (
  echo [1/5] Создаю .env из .env.example...
  copy /y ".env.example" ".env" >nul
) else (
  echo [1/5] .env найден.
)

echo [2/5] Проверяю проект...
call npm run check
if errorlevel 1 (
  echo.
  echo [ОШИБКА] Проверка не пройдена.
  pause
  exit /b 1
)

echo [3/5] Запускаю локальный self-test...
call npm run selftest
if errorlevel 1 (
  echo.
  echo [ОШИБКА] Локальный self-test не пройден.
  pause
  exit /b 1
)

echo [4/5] Проверяю настройки Telegram...
node diagnose.js
if errorlevel 1 (
  echo.
  echo [ПОДСКАЗКА] Telegram сейчас не прошёл проверку.
  echo Проверь TELEGRAM_BOT_TOKEN в .env.
  echo.
)

echo [5/5] Запускаю сайт и Telegram-бота...
echo Окно не закрывай, пока бот должен работать.
echo.
call npm start

echo.
echo Процесс завершён.
pause
