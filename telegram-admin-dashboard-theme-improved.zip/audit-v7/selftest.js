#!/usr/bin/env node
'use strict';
const assert=require('assert');
const path=require('path');
process.env.NODE_ENV='development';
process.env.BOT_MODE='polling';
process.env.TELEGRAM_BOT_TOKEN='123456789:SELFTEST_TOKEN';
process.env.TELEGRAM_GROUP_ID='-100999';
const { _test }=require('./bot');
const { onJoinRequest,onChatMember,markProcessed,adminByTelegram }=_test;
function fresh(){return {admins:[{id:1,name:'Тест',role:'Управляющая',telegram:'@tester',telegramId:'555111222',bans:0,accepted:0}],roles:[{name:'Управляющая',banNorm:40,acceptNorm:80}],requests:[],bans:[],activity:[],telegram:{lastUpdateId:0,processedUpdateIds:[]}}}
(async()=>{
  const s=fresh();
  assert.strictEqual(adminByTelegram(s,{id:555111222,username:'tester'}).id,1);
  assert.strictEqual(await onJoinRequest({chat:{id:-100999},from:{id:777888,first_name:'Пётр',last_name:'Иванов',username:'petr'},date:1},s),true);
  assert.strictEqual(s.requests[0].telegramUserId,'777888');
  assert.strictEqual(s.requests[0].user,'@petr');
  assert.strictEqual(await onJoinRequest({chat:{id:-100999},from:{id:777888,first_name:'Пётр',username:'petr'},date:1},s),false);
  assert.strictEqual(s.requests.length,1);
  const beforeAccepted=s.admins[0].accepted;
  assert.strictEqual(await onChatMember({chat_member:{chat:{id:-100999},from:{id:555111222,first_name:'Тест'},date:1,old_chat_member:{status:'left',user:{id:777888}},new_chat_member:{status:'member',user:{id:777888}}}},s),true);
  assert.strictEqual(s.requests[0].status,'accepted');
  assert.strictEqual(s.requests[0].acceptedBy,'Тест');
  assert.strictEqual(s.admins[0].accepted,beforeAccepted+1);
  await onChatMember({chat_member:{chat:{id:-100999},from:{id:555111222},date:1,old_chat_member:{status:'member',user:{id:888999}},new_chat_member:{status:'kicked',user:{id:888999,first_name:'Спамер'}}}},s);
  assert.strictEqual(s.bans.length,1);
  assert.strictEqual(s.bans[0].uid,'888999');
  assert.strictEqual(s.admins[0].bans,1);
  assert.strictEqual(markProcessed(s,10),true);
  assert.strictEqual(markProcessed(s,10),false);
  console.log('SELFTEST OK: join request, acceptance, ban tracking, username mapping and update deduplication');
})().catch(e=>{console.error('SELFTEST FAILED:',e.message);process.exit(1)});
